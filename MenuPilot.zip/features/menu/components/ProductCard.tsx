"use client";

import { ThemedCard } from "@/components/themed/ThemedCard";
import { ThemedButton } from "@/components/themed/ThemedButton";

type ProductVariant = {
  id: string;
  name: string;
  base_price: number;
  is_default: boolean;
  is_enabled: boolean;
  sort_order: number;
};

type Product = {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  base_price: number | null;
  builder_template: string;
  has_variants: boolean;
  is_featured: boolean;
  is_enabled: boolean;
  variants?: ProductVariant[];
};

type ProductCardProps = {
  product: Product;
  onCustomize?: (productId: string) => void;
  isLoading?: boolean;
};

function getStartingPrice(product: Product) {
  if (product.has_variants && !product.variants?.length) {
    return null;
  }

  if (product.has_variants && product.variants?.length) {
    const sorted = [...product.variants].sort(
      (a, b) => a.base_price - b.base_price,
    );

    return sorted[0]?.base_price ?? null;
  }

  return product.base_price;
}

export function ProductCard({
  product,
  onCustomize,
  isLoading = false,
}: ProductCardProps) {
  const startingPrice = getStartingPrice(product);
  const canCustomize =
    !product.has_variants || (product.variants?.length ?? 0) > 0;

  function handleCustomize() {
    if (!canCustomize) return;

    onCustomize?.(product.id);
  }

  return (
    <ThemedCard className="flex h-full flex-col justify-between p-5">
      <div>
        <div className="mb-3 flex items-start justify-between gap-4">
          <h3 className="text-xl font-semibold">{product.name}</h3>

          {product.is_featured ? (
            <span className="rounded-full bg-primary/10 px-2 py-1 text-xs font-medium text-primary">
              Featured
            </span>
          ) : null}
        </div>

        {product.description ? (
          <p className="text-sm text-muted-foreground">{product.description}</p>
        ) : null}
      </div>

      <div className="mt-5 flex items-center justify-between gap-4">
        <p className="font-semibold">
          {!canCustomize
            ? "Unavailable"
            : startingPrice !== null
            ? `Starting at $${startingPrice.toFixed(2)}`
            : "Price varies"}
        </p>

        <ThemedButton
          size="sm"
          disabled={isLoading || !canCustomize}
          onClick={handleCustomize}
        >
          {!canCustomize ? "Unavailable" : isLoading ? "Loading..." : "Customize"}
        </ThemedButton>
      </div>
    </ThemedCard>
  );
}
