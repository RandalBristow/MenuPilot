"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Plus } from "lucide-react"
import { AdminBackButton } from "@/components/themed/AdminBackButton"
import { CompactRecordStatusIcon } from "@/components/themed/CompactRecordStatusIcon"
import { ThemedButton } from "@/components/themed/ThemedButton"
import { ThemedCard } from "@/components/themed/ThemedCard"
import { ThemedPageHeader } from "@/components/themed/ThemedPageHeader"
import { ModifierGroupFormDialog } from "@/features/admin-modifiers/components/ModifierGroupFormDialog"
import type {
  ModifierGroupCategory,
  RawModifierGroup,
} from "@/features/admin-modifiers/components/ModifiersCategoryBrowser"

type ModifierCategoryGroupsClientProps = {
  categories: ModifierGroupCategory[]
  category: ModifierGroupCategory
}

function sortGroups(groups: RawModifierGroup[]) {
  return [...groups].sort((first, second) => {
    if (first.sort_order !== second.sort_order) {
      return first.sort_order - second.sort_order
    }

    return first.name.localeCompare(second.name)
  })
}

function formatGroupRules(group: RawModifierGroup) {
  const requiredLabel = group.is_required ? "Required" : "Optional"
  const maxAllowed = group.max_allowed ?? "No max"

  return `${requiredLabel} - ${group.selection_type} - min ${group.min_required} - max ${maxAllowed}`
}

function formatModifierGroupTitle(categoryName: string) {
  const contextName = categoryName.replace(/\s+modifiers?$/i, "").trim()

  return `${contextName || categoryName} Modifier Groups`
}

export function ModifierCategoryGroupsClient({
  categories,
  category,
}: ModifierCategoryGroupsClientProps) {
  const router = useRouter()
  const [selectedCategoryId, setSelectedCategoryId] = useState(category.id)
  const [activeGroup, setActiveGroup] = useState<RawModifierGroup | null>(null)
  const groups = sortGroups(category.modifier_groups)

  return (
    <main className="flex h-dvh min-h-screen overflow-hidden bg-background px-4 py-5 sm:px-6 lg:px-8">
      <div className="mx-auto flex min-h-0 w-full max-w-5xl flex-col space-y-4">
        <div className="shrink-0 space-y-3 border-b pb-3">
          <ThemedPageHeader
            title={formatModifierGroupTitle(category.name)}
            description={`Reusable subgroups inside ${category.name}.`}
          />
        </div>

        <div className="no-scrollbar min-h-0 flex-1 space-y-2 overflow-y-auto pb-3">
          {groups.length === 0 ? (
            <ThemedCard className="p-5 text-center">
              <p className="font-semibold">No modifier subgroups yet</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Add reusable subgroups like Crust Type, Toppings, or Sauce.
              </p>
            </ThemedCard>
          ) : (
            groups.map((group) => (
              <ThemedCard
                key={group.id}
                role="button"
                tabIndex={0}
                aria-label={`Edit modifier subgroup ${group.name}`}
                onClick={() => setActiveGroup(group)}
                onKeyDown={(event) => {
                  if (
                    event.target === event.currentTarget &&
                    (event.key === "Enter" || event.key === " ")
                  ) {
                    event.preventDefault()
                    setActiveGroup(group)
                  }
                }}
                className={
                  group.is_enabled
                    ? "cursor-pointer gap-0 overflow-hidden p-0"
                    : "cursor-pointer gap-0 overflow-hidden bg-muted/30 p-0 opacity-75"
                }
              >
                <div className="px-3 pt-2.5">
                  <div className="space-y-1.5">
                    <div className="flex min-w-0 items-center gap-2">
                      <CompactRecordStatusIcon enabled={group.is_enabled} />
                      <div className="min-w-0 flex-1 truncate text-sm font-semibold leading-5 text-foreground">
                        {group.name}
                      </div>
                    </div>

                    <p className="text-xs leading-5 text-muted-foreground">
                      {formatGroupRules(group)}
                    </p>
                  </div>
                </div>

                <div className="flex justify-end px-3 pb-2.5 pt-1.5">
                  <ThemedButton
                    type="button"
                    variant="outline"
                    className="h-8 bg-background px-3 text-xs text-foreground hover:bg-muted"
                    onClick={(event) => {
                      event.stopPropagation()
                      router.push(`/admin/modifiers/${group.id}`)
                    }}
                  >
                    Manage Option Lists
                  </ThemedButton>
                </div>
              </ThemedCard>
            ))
          )}
        </div>

        <div className="shrink-0 border-t bg-background pt-3">
          <div className="flex justify-end gap-2">
            <AdminBackButton
              fallbackHref="/admin/modifiers/groups"
              label="Back to modifier groups"
            />
            <ModifierGroupFormDialog
              categories={categories}
              selectedCategoryId={selectedCategoryId}
              triggerIcon={<Plus aria-hidden="true" />}
              triggerAriaLabel="New Modifier Subgroup"
              onCreated={setSelectedCategoryId}
            />
          </div>
        </div>

        {activeGroup ? (
          <ModifierGroupFormDialog
            open={Boolean(activeGroup)}
            onOpenChange={(open) => {
              if (!open) setActiveGroup(null)
            }}
            categories={categories}
            selectedCategoryId={category.id}
            mode="edit"
            group={activeGroup}
            onCreated={setSelectedCategoryId}
          />
        ) : null}
      </div>
    </main>
  )
}
