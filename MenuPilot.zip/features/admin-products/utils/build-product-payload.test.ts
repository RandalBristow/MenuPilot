import { describe, expect, it } from "vitest"
import { buildProductPayload } from "./build-product-payload"

function createProductFormData(overrides: Record<string, string | string[]> = {}) {
  const values = {
    name: "Large Pepperoni Pizza",
    description: "Classic pizza",
    basePrice: "14.99",
    builderTemplate: "pizza",
    menuGroupId: "menu-group-pizza",
    modifierGroupIds: ["modifier-crust", "modifier-toppings"],
    ...overrides,
  }

  const formData = new FormData()

  Object.entries(values).forEach(([key, value]) => {
    if (Array.isArray(value)) {
      value.forEach((item) => formData.append(key, item))
      return
    }

    formData.set(key, value)
  })

  return formData
}

describe("buildProductPayload", () => {
  it("builds a valid product payload", () => {
    const payload = buildProductPayload(createProductFormData())

    expect(payload.product).toEqual({
      name: "Large Pepperoni Pizza",
      slug: "large-pepperoni-pizza",
      description: "Classic pizza",
      base_price: 14.99,
      builder_template: "pizza",
      has_variants: true,
      is_enabled: true,
    })
  })

  it("trims product name", () => {
    const payload = buildProductPayload(
      createProductFormData({ name: "  Garden Salad  " })
    )

    expect(payload.product.name).toBe("Garden Salad")
    expect(payload.product.slug).toBe("garden-salad")
  })

  it("rejects empty product name", () => {
    expect(() =>
      buildProductPayload(createProductFormData({ name: "   " }))
    ).toThrow("Product name is required.")
  })

  it("rejects negative base price", () => {
    expect(() =>
      buildProductPayload(createProductFormData({ basePrice: "-1" }))
    ).toThrow("Base price must be zero or greater.")
  })

  it("allows no modifier groups", () => {
    const payload = buildProductPayload(
      createProductFormData({ modifierGroupIds: [] })
    )

    expect(payload.modifierGroupIds).toEqual([])
  })

  it("preserves selected menu group id", () => {
    const payload = buildProductPayload(
      createProductFormData({ menuGroupId: "menu-group-wings" })
    )

    expect(payload.menuGroupId).toBe("menu-group-wings")
  })

  it("preserves selected modifier group ids", () => {
    const payload = buildProductPayload(
      createProductFormData({
        modifierGroupIds: ["modifier-sauce", "modifier-size"],
      })
    )

    expect(payload.modifierGroupIds).toEqual([
      "modifier-sauce",
      "modifier-size",
    ])
  })

  it("marks products as variant-ready for reusable group assignments", () => {
    const payload = buildProductPayload(createProductFormData())

    expect(payload.product.has_variants).toBe(true)
  })
})
